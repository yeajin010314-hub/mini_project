<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%
    String savedId = (String) session.getAttribute("savedId");
    Integer autoCheck = (Integer) session.getAttribute("autoCheck");
    boolean isChecked = (savedId != null) && (autoCheck != null && autoCheck == 1);
%>

<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>여기서놀자|로그인</title>
<meta name = "viewport" content="width=device-width, initial-scale=1.0"/>
<style>
* {
    box-sizing: border-box;
    font-family: 'Segoe UI', sans-serif;
}

body {
    margin: 0;
    background: #f4f4f4;
}

/* ===== 상단 ===== */
.header {
    height: 60px;
    background: #ffffff;
    border-bottom: 1px solid #ddd;
    display: flex;
    align-items: center;
    padding: 0 24px;
}

.logo a{
    font-size: 22px;
    font-weight: 700;
    color: #333;
    cursor: pointer;
    text-decoration:none;
    color :inherit;
}

/* ===== 로그인 영역 ===== */
.container {
    height: calc(100vh - 60px);
    display: flex;
    justify-content: center;
    align-items: center;
}

.login-card {
    width: 360px;
    background: #ffffff;
    border-radius: 14px;
    padding: 32px;
    box-shadow: 0 6px 18px rgba(0,0,0,0.08);
}

.login-card h2 {
    text-align: center;
    margin-bottom: 26px;
    color: #333;
}

/* 입력 */
.input-group {
    margin-bottom: 16px;
}

.input-group label {
    font-size: 13px;
    color: #555;
}

.input-group input {
    width: 100%;
    padding: 10px;
    margin-top: 6px;
    border-radius: 8px;
    border: 1px solid #ccc;
}

.input-group input:focus {
    outline: none;
    border-color: #888;
}

/* 아이디 저장 */
.save-id {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 13px;
    color: #555;
    margin-top: 6px;
}

/* 에러 */
.error-msg {
    font-size: 12px;
    color: #d32f2f;
    display: none;
    margin-top: 10px;
}

/* 로그인 버튼 */
.login-btn {
    width: 100%;
    margin-top: 20px;
    padding: 12px;
    border: none;
    border-radius: 10px;
    background: #444;
    color: white;
    font-size: 15px;
    cursor: pointer;
}

.login-btn:hover {
    background: #333;
}

/* 하단 링크 */
.sub-links {
    display: flex;
    justify-content: center;
    gap: 12px;
    margin-top: 20px;
    font-size: 13px;
    color: #666;

}

.sub-links a{
	text-align: none;
	color: inherit;
	cursor : pointer;

}

.sub-links span {
    cursor: pointer;
}

.sub-links span:hover {
    text-decoration: underline;
}
</style>
</head>

<body onload="begin()">

<div class="header">
    <div class="logo">
        <a href="/mini_project/main/mainForm.jsp">여기서놀자</a>
    </div>
</div>

<div class="container">
<div class="login-card">
    <h2>로그인</h2>

    <form action="<%=request.getContextPath()%>/login/loginPro2"
      name="myForm"
      method="post"
      onsubmit="return checkIt()">

        <div class="input-group">
            <label>아이디</label>
            <input type="text" name="memberId" id="loginId"
                   value="<%= savedId != null ? savedId : "" %>">
        </div>

        <div class="input-group">
            <label>비밀번호</label>
            <input type="password" name="passwd" id="loginPw">
        </div>

        <div class="save-id">
            <label>
                <input type="checkbox" name="autoid" value="1"
                       <%= isChecked ? "checked" : "" %>>
                아이디 저장
            </label>
        </div>

        <input type="submit" value="로그인" class="login-btn">
    </form>

    <div class="sub-links">
        <span>아이디 찾기</span>
        <span>비밀번호 찾기</span>
        <a href="/mini_project/join/joinForm2.jsp">회원가입</a>
    </div>
</div>
</div>

<script>
function begin() {
    document.getElementById("loginId").focus();
}

function checkIt() {
    if (!loginId.value) {
        alert("아이디를 입력하세요.");
        loginId.focus();
        return false;
    }
    if (!loginPw.value) {
        alert("비밀번호를 입력하세요.");
        loginPw.focus();
        return false;
    }
    return true;
}
</script>

</body>
</html>
