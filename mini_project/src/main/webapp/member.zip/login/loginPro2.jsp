<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="web.member.MemberDAO2" %>
<%@ page import="web.member.MemberDTO" %>

<%
    /* ================= 1. 인코딩 ================= */
    request.setCharacterEncoding("UTF-8");

    /* ================= 2. 파라미터 받기 ================= */
    String memberId = request.getParameter("memberId");
    String passwd   = request.getParameter("passwd");
    String saveId   = request.getParameter("autoid"); // 체크박스

    /* ================= 3. 서버 검증 ================= */
    if(memberId == null || memberId.trim().equals("") ||
       passwd == null   || passwd.trim().equals("")) {

        response.sendRedirect("loginForm2.jsp?error=empty");
        return;
    }

    /* ================= 4. DAO 로그인 처리 ================= */
    MemberDAO2 dao = MemberDAO2.getInstance();
    MemberDTO loginUser = dao.login(memberId, passwd); // ★ DAO에 있어야 함

    /* ================= 5. 로그인 실패 ================= */
    if(loginUser == null) {
        response.sendRedirect("loginForm2.jsp?error=fail");
        return;
    }

    /* ================= 6. 로그인 성공 → 세션 처리 ================= */
    session.setAttribute("loginUser", loginUser);

    /* ================= 7. 아이디 저장 (세션) ================= */
    if(saveId != null) { // 체크했을 때
        session.setAttribute("savedId", memberId);
    } else {             // 체크 안 했을 때
        session.removeAttribute("savedId");
    }

    /* ================= 8. 메인으로 이동 ================= */
    response.sendRedirect("/mini_project/main/mainForm.jsp");
%>
