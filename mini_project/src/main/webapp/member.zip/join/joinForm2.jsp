<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>여기서놀자|회원가입</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
* { box-sizing: border-box; }

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: url("background.jpg") no-repeat center center fixed;
    background-size: cover;
}

/* ===== 상단바 ===== */
.topbar {
    background: rgba(0,0,0,0.75);
    padding: 15px 30px;
    color: #fff;
}

.logo {
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
    text-decoration: none;
    color: inherit;
}

/* ===== 메인 ===== */
.main {
    max-width: 480px;
    margin: 60px auto;
    background: rgba(255,255,255,0.95);
    padding: 40px;
    border-radius: 14px;
}

/* ===== 제목 ===== */
.title {
    text-align: center;
    font-size: 22px;
    font-weight: bold;
    margin-bottom: 30px;
}

/* ===== 폼 ===== */
.form-group {
    margin-bottom: 18px;
}

.form-group label {
    display: block;
    margin-bottom: 6px;
    font-size: 14px;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 12px;
    font-size: 14px;
    border-radius: 8px;
    border: 1px solid #ccc;
    outline: none;
}

/* ===== 아이디 ===== */
.id-wrap {
    display: flex;
    gap: 8px;
}

.id-wrap button {
    width: 90px;
    cursor: pointer;
}

.msg {
    margin-top: 6px;
    font-size: 13px;
}

/* ===== 생년월일 ===== */
.birth-wrap {
    position: relative;
}

.birth-wrap input[type="date"] {
    width: 100%;
    padding: 12px;
    font-size: 14px;
    border-radius: 8px;
    border: 1px solid #ccc;
    outline: none;
    cursor: pointer;
}

.birth-wrap input[type="date"]:focus {
    border-color: #888;
}

/* ===== 이메일 ===== */
.email-wrap {
    display: flex;
    align-items: center;
    gap: 6px;
}

.email-wrap input {
    flex: 1;
}

.email-wrap select {
    width: 140px;
}

/* ===== 버튼 ===== */
.submit-btn {
    width: 100%;
    padding: 14px;
    font-size: 16px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    background: #333;
    color: #fff;
    margin-top: 10px;
}

/* ===== 하단 ===== */
.bottom-text {
    text-align: center;
    margin-top: 18px;
    font-size: 14px;
}
.bottom-text a{
    text-decoration: none;
    color: inherit;
    font-weight: bold;
    cursor: pointer;
}
</style>
</head>

<body>
<form action="<%=request.getContextPath()%>/member/join" method="post" onsubmit="return join();">

<!-- 상단 -->
<div class="topbar">
    <a href="<%=request.getContextPath()%>/main/mainForm.jsp" class="logo">여기서놀자</a>
</div>

<div class="main">
    <div class="title">회원가입</div>

    <div class="form-group">
        <label>회원명</label>
        <input type="text" name="memberNm" placeholder="이름입력" required>
    </div>

    <div class="form-group">
        <label>닉네임</label>
        <input type="text" id="nick" name="nickNm" placeholder="닉네임 입력">
        <button type="button" onclick="checkNick()">중복확인</button>
        <div id="nickMsg" class="msg"></div>
    </div>

    <div class="form-group">
        <label>전화번호</label>
        <input type="text" id="phone" name="telNo" placeholder="숫자만 입력"
               oninput="onlyNumber(this)" inputmode="numeric">
        <div id="phoneMsg" class="msg" style="color:red; display:none;">
            *숫자만 입력 가능합니다
        </div>
    </div>

    <!-- 생년월일 -->
    <div class="form-group">
        <label>생년월일</label>
        <div class="birth-wrap">
            <input type="date" name="birth" id="birth" required>
        </div>
    </div>

    <!-- 아이디 -->
    <div class="form-group">
        <label>회원아이디</label>
        <div class="id-wrap">
            <input type="text" id="userId" name="memberId" placeholder="아이디 입력">
            <button type="button" onclick="checkId()">중복확인</button>
        </div>
        <div id="idMsg" class="msg"></div>
    </div>

    <!-- 비밀번호 -->
    <div class="form-group">
        <label>비밀번호</label>
        <input type="password" id="pw" name="passwd" placeholder="비밀번호 입력">
    </div>

    <div class="form-group">
        <label>비밀번호 확인</label>
        <input type="password" id="pwCheck" placeholder="비밀번호 다시 입력" onkeyup="checkPassword()">
        <div id="pwMsg" class="msg" style="color:red; display:none;">
            *비밀번호가 일치하지 않습니다
        </div>
    </div>

    <!-- 이메일 -->
    <div class="form-group">
        <label>이메일</label>
        <div class="email-wrap">
            <input type="text" id="emailId" placeholder="이메일 아이디">
            @
            <select id="emailDomain" onchange="toggleDomainInput()">
                <option value="naver.com">naver.com</option>
                <option value="daum.net">daum.net</option>
                <option value="nate.com">nate.com</option>
                <option value="gmail.com">gmail.com</option>
                <option value="outlook.com">outlook.com</option>
                <option value="custom">--직접입력--</option>
            </select>
            <input type="text" id="customDomain" placeholder="직접입력" style="display:none;">
        </div>
    </div>

    <!-- 서버로 보낼 이메일 -->
    <input type="hidden" name="email" id="fullEmail">

    <button class="submit-btn" type="submit">가입하기</button>

    <div class="bottom-text">
        이미 계정이 있나요?
        <a href="<%=request.getContextPath()%>/member/login/loginForm2.jsp">로그인</a>
    </div>
</div>

</form>

<script>
const ctx = "<%=request.getContextPath()%>";

let idChecked = false;
let nickChecked = false;

/* 입력 변경 시 중복확인 상태 초기화 */
document.addEventListener("DOMContentLoaded", () => {
  const idInput = document.getElementById("userId");
  const nickInput = document.getElementById("nick");

  if (idInput) {
    idInput.addEventListener("input", () => {
      idChecked = false;
      const msg = document.getElementById("idMsg");
      if (msg) msg.innerText = "";
    });
  }

  if (nickInput) {
    nickInput.addEventListener("input", () => {
      nickChecked = false;
      const msg = document.getElementById("nickMsg");
      if (msg) msg.innerText = "";
    });
  }
});

/* 아이디 중복확인 */
function checkId() {
  const idInput = document.getElementById("userId");
  const msg = document.getElementById("idMsg");
  if (!idInput || !msg) return;

  const id = idInput.value.trim();
  const idRegex = /^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{5,15}$/;

  if (!idRegex.test(id)) {
    msg.style.color = "red";
    msg.innerText = "영문+숫자 5~15자로 입력하세요.";
    idChecked = false;
    return;
  }
  
  const url = ctx+"/member/check?type=memberId&value="+encodeURIComponent(id)
	console.log("ID CHECK URL =", url);
  
	fetch(url)	  
    .then(res => res.text())
    .then(data => {
      data = data.trim().toUpperCase();
      if (data === "DUP") {
        msg.style.color = "red";
        msg.innerText = "이미 사용 중인 아이디입니다.";
        idChecked = false;
      } else {
        msg.style.color = "green";
        msg.innerText = "사용 가능한 아이디입니다.";
        idChecked = true;
      }
    })
    .catch(() => {
      msg.style.color = "red";
      msg.innerText = "중복확인 통신 오류";
      idChecked = false;
    });
}

/* 닉네임 중복확인 */
function checkNick() {
  const nickInput = document.getElementById("nick");
  const msg = document.getElementById("nickMsg");
  if (!nickInput || !msg) return;
  
  const nick = nickInput.value.trim();
  console.log("NICK =", nick);

  if (nick.length < 2 || nick.length > 6) {
    msg.style.color = "red";
    msg.innerText = "닉네임은 2~6자로 입력하세요.";
    nickChecked = false;
    return;
  }
	const url = ctx+ "/member/check?type=nickNm&vlaue="+encodeURIComponent(nick)
	console.log("NICK CHECK URL =",url);		
 
	fetch(url)
    .then(res => res.text())
    .then(data => {
      data = data.trim().toUpperCase();
      if (data === "DUP") {
        msg.style.color = "red";
        msg.innerText = "이미 사용 중인 닉네임입니다.";
        nickChecked = false;
      } else {
        msg.style.color = "green";
        msg.innerText = "사용 가능한 닉네임입니다.";
        nickChecked = true;
      }
    })
    .catch(() => {
      msg.style.color = "red";
      msg.innerText = "중복확인 통신 오류";
      nickChecked = false;
    });
}

/* 전화번호 숫자만 */
function onlyNumber(input) {
  const reg = /[^0-9]/g;
  if (reg.test(input.value)) {
    input.value = input.value.replace(reg, "");
    const phoneMsg = document.getElementById("phoneMsg");
    if (phoneMsg) phoneMsg.style.display = "block";
  } else {
    const phoneMsg = document.getElementById("phoneMsg");
    if (phoneMsg) phoneMsg.style.display = "none";
  }
}

/* 비밀번호 확인 */
function checkPassword() {
  const pw = document.getElementById("pw")?.value || "";
  const pwCheck = document.getElementById("pwCheck")?.value || "";
  const msg = document.getElementById("pwMsg");
  if (!msg) return;

  if (!pwCheck) {
    msg.style.display = "none";
    return;
  }
  msg.style.display = (pw !== pwCheck) ? "block" : "none";
}

/* 이메일 도메인 직접입력 토글 */
function toggleDomainInput() {
  const domainSel = document.getElementById("emailDomain")?.value;
  const custom = document.getElementById("customDomain");
  if (!custom) return;

  if (domainSel === "custom") {
    custom.style.display = "block";
    custom.focus();
  } else {
    custom.style.display = "none";
    custom.value = "";
  }
}

/* 가입 버튼 검증 */
function join() {
  const emailId = document.getElementById("emailId")?.value.trim() || "";
  const domainSel = document.getElementById("emailDomain")?.value || "";
  const customDomain = document.getElementById("customDomain")?.value.trim() || "";
  const domain = (domainSel === "custom") ? customDomain : domainSel;

  const full = (emailId && domain) ? (emailId + "@" + domain) : "";
  const fullEmailEl = document.getElementById("fullEmail");
  if (fullEmailEl) fullEmailEl.value = full;

  if (!full) {
    alert("이메일을 입력하세요.");
    return false;
  }
  if (!idChecked) {
    alert("아이디 중복확인을 해주세요.");
    return false;
  }
  if (!nickChecked) {
    alert("닉네임 중복확인을 해주세요.");
    return false;
  }
  return true;
}
</script>


</body>
</html>
