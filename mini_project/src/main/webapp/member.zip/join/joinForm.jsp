<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>


<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>여기서놀자|회원가입</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
* { box-sizing: border-box; }

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: url("background.jpg") no-repeat center center fixed;
    background-size: cover;
}

/* ===== 상단바 ===== */
.topbar {
    background: rgba(0,0,0,0.75);
    padding: 15px 30px;
    color: #fff;
}

.logo {
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
    text-decoration: none;   /* 밑줄 제거 */
	color: inherit;          /* 기본 링크 색 제거 */
}

/* ===== 메인 ===== */
.main {
    max-width: 480px;
    margin: 60px auto;
    background: rgba(255,255,255,0.95);
    padding: 40px;
    border-radius: 14px;
}

/* ===== 제목 ===== */
.title {
    text-align: center;
    font-size: 22px;
    font-weight: bold;
    margin-bottom: 30px;
}

/* ===== 폼 ===== */
.form-group {
    margin-bottom: 18px;
}

.form-group label {
    display: block;
    margin-bottom: 6px;
    font-size: 14px;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 12px;
    font-size: 14px;
    border-radius: 8px;
    border: 1px solid #ccc;
    outline: none;
}

/* ===== 아이디 ===== */
.id-wrap {
    display: flex;
    gap: 8px;
}

.id-wrap button {
    width: 90px;
    cursor: pointer;
}

.msg {
    margin-top: 6px;
    font-size: 13px;
}


/* ===== 생년월일 ===== */
.birth-wrap {
    position: relative;
}

.birth-wrap input[type="date"] {
    width: 100%;
    padding: 12px;
    font-size: 14px;
    border-radius: 8px;
    border: 1px solid #ccc;
    outline: none;
    cursor: pointer;
}

.birth-wrap input[type="date"]:focus {
    border-color: #888;
}

/* ===== 이메일 ===== */
.email-wrap {
    display: flex;
    align-items: center;
    gap: 6px;
}

.email-wrap input {
    flex: 1;
}

.email-wrap select {
    width: 140px;
}

/* ===== 버튼 ===== */
.submit-btn {
    width: 100%;
    padding: 14px;
    font-size: 16px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    background: #333;
    color: #fff;
    margin-top: 10px;
}

/* ===== 하단 ===== */
.bottom-text {
    text-align: center;
    margin-top: 18px;
    font-size: 14px;
}    
.bottom-text a{
    text-decoration: none;   /* 밑줄 제거 */
	color: inherit;          /* 기본 링크 색 제거 */
	font-weight: bold;
	cursor: pointer;
}

.bottom-text span {
    cursor: pointer;
    font-weight: bold;
}
</style>
</head>

<body>
<form action="/mini_project/join/joinPro.jsp" method="post" onsubmit="return join();">
<!-- 상단 -->
<div class="topbar">
	<a href="mainForm.jsp" class="logo">여기서놀자</a>
	
</div>

<div class="main">
	<div class="title">회원가입</div>
	
	<div class="form-group">
		<label>회원명</label>
		<input type="text" name="memberNm" placeholder="이름입력" required>
	</div>	

	<div class="form-group">
		<label>닉네임</label>
		<input type="text" id="nick" name="nickNm" placeholder="닉네임 입력">
		<button type="button" onclick="checkNick()">중복확인</button>
		<div id ="nickMsg" class="msg"></div>
	</div>

	<div class="form-group">
		<label>전화번호</label>
		<input type="text" id="phone"
			name="telNo"
			placeholder="숫자만 입력"
			onkeyup="onlyNumber(this)">
		<div id = "phoneMsg" class="msg" style="color:red; display:none;">
		*숫자만 입력 가능합니다
	</div>
	</div>
	
	<!-- 생년월일 -->
	<div class="form-group">
		<label>생년월일</label>
		<div class="birth-wrap">
		<input type="date" name="birth" id="birth" required>
	</div>
	</div>
	
	<!-- 아이디 -->
	<div class="form-group">
		<label>회원아이디</label>
		<div class="id-wrap">
			<input type="text" id="userId" name="memberId" placeholder="아이디 입력">
			<button type="button" onclick="checkId()">중복확인</button>
		</div>
		<div id="idMsg" class="msg"></div>
	</div>
	
	<!-- 비밀번호 -->
	<div class="form-group">
		<label>비밀번호</label>
		<input type="password" id="pw" name="passwd" placeholder="비밀번호 입력">
	</div>
	
	<div class="form-group">
		<label>비밀번호 확인</label>
		<input type="password" id="pwCheck" placeholder="비밀번호 다시 입력" onkeyup="checkPassword()">
		<div id="pwMsg" class="msg" style="color:red; display:none;">
		*비밀번호가 일치하지 않습니다
	</div>
	</div>	
	
	<!-- 이메일 -->
	<div class="form-group">
		<label>이메일</label>
		<div class="email-wrap">
		<input type="text" id="emailId" placeholder="이메일 아이디">
		@
		<select id="emailDomain" onchange="toggleDomainInput()">
			<option value="naver.com">naver.com</option>
			<option value="daum.net">daum.net</option>
			<option value="nate.com">nate.com</option>
			<option value="gmail.com">gmail.com</option>
			<option value="outlook.com">outlook.com</option>
			
			<option value="custom">--직접입력--</option>
		</select>
		<input type="text" id="customDomain" placeholder="직접입력" style="display:none;">
		</div>
	</div>
	<!-- 서버로 보낼 이메일 -->
	<input type="hidden" name="email" id="fullEmail">
	
	
	<button class="submit-btn" type="submit">가입하기</button>
	
	<div class="bottom-text">
		이미 계정이 있나요? <a href="/mini_project/login/loginForm.jsp">로그인</a>
		</div>
	</div>

	
	


</form>


<script>
let idChecked = false;
let nickChecked = false;

/*아이디 중복확인*/
 function checkId() {
    const id = document.getElementById("userId").value.trim();
    const msg = document.getElementById("idMsg");

    // 영문 + 숫자 + 5~10자
    const idRegex = /^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{5,10}$/;

    if (!idRegex.test(id)) {
        msg.style.color = "red";
        msg.innerText = "영문+숫자 5~10자로 입력하세요.";
        idChecked = false;
        return;
    }

    fetch("/mini_project/member/check", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "type=memberId&value=" + encodeURIComponent(id)
    })
    .then(res => res.text())
    .then(data => {
        if (data === "DUP") {
            msg.style.color = "red";
            msg.innerText = "이미 사용 중인 아이디입니다.";
            idChecked = false;
        } else {
            msg.style.color = "green";
            msg.innerText = "사용 가능한 아이디입니다.";
            idChecked = true;
        }
    });
}

 /* 닉네임 중복확인 */
 function checkNick() {
     const nick = document.getElementById("nick").value.trim();
     const msg = document.getElementById("nickMsg");

     if (nick.length < 2 || nick.length > 6) {
         msg.style.color = "red";
         msg.innerText = "닉네임은 2~6자로 입력하세요.";
         nickChecked = false;
         return;
     }

     fetch("/mini_project/member/check", {
         method: "POST",
         headers: { "Content-Type": "application/x-www-form-urlencoded" },
         body: "type=nickNm&value=" + encodeURIComponent(nick)
     })
     .then(res => res.text())
     .then(data => {
         if (data === "DUP") {
             msg.style.color = "red";
             msg.innerText = "이미 사용 중인 닉네임입니다.";
             nickChecked = false;
         } else {
             msg.style.color = "green";
             msg.innerText = "사용 가능한 닉네임입니다.";
             nickChecked = true;
         }
     });
 }

/*비밀번호*/
function checkPassword(){
	const pw = document.getElementById("pw").value;
	const pwCheck =document.getElementById("pwCheck").value;
	const msg = document.getElementById("pwMsg");
	
	if (pwCheck && pw !==pwCheck){
		msg.style.display = "block";
	}else{
		msg.style.display = "none"		
	}
}
/*이메일*/
 function toggleDomainInput(){
	const domainSelect = document.getElementById("emailDomain");
	const custom = document.getElementById("customDomain");
	
	if(domainSelect.value === "custom") {
		custom.style.display = "block";
		custom.value = "";
	}else{
		custom.style.display ="none";
	}
}

/*이메일 합치기 작업*/
function makeEmail(){
	const id = document.getElementById("emailId").value;
	const domainSelect = document.getElementById("emailDomain").value;
	const custom = document.getElementById("customDomain").value;
	
	let domain = domainSelect === "custom" ? custom : domainSelect;
	document.getElementById("fullEmail").value = id + "@" + domain;
}
 
/*연락처 도메인*/
function onlyNumber(input){
	const reg = /[^0-9]/g;
	
	if(reg.test(input.value)){
		input.value=input.value.replace(reg,'');
		document.getElementById("phoneMsg").style.display = "block";
	}else{
		document.getElementById("phoneMsg").style.display = "none";
	}
	
}

/*가입*/
function join() {
	if(!nickChecked){
		alert("닉네임 중복확인을 해주세요");
		return false;
	}
	
    if(!idChecked){
        alert("아이디 중복확인을 해주세요.");
        return false;
    }

    const pw = document.getElementById("pw").value;
    const pwCheck = document.getElementById("pwCheck").value;

    if(pw !== pwCheck){
        alert("비밀번호가 일치하지 않습니다.");
        return false;
    }

    makeEmail();
    return true;
}


 

</script>
</body>


</html>
