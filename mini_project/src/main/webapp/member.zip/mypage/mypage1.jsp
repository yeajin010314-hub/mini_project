<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%
    request.setCharacterEncoding("UTF-8");

    // ===== 세션 값 =====
    String sid = (String) session.getAttribute("sid");
    String sname = (String) session.getAttribute("sname");   // 이름
    String snick = (String) session.getAttribute("snick");   // 닉네임
    String semail = (String) session.getAttribute("semail"); // 이메일
    String reporter = (String) session.getAttribute("reporter"); // N / WAIT / Y

    if (sid == null) {
        response.sendRedirect("/mini_project/login/loginForm2.jsp");
        return;
    }

    if (reporter == null) reporter = "N";
%>

<!DOCTYPE html>
<html lang="ko">
<head> 
<meta charset="UTF-8">
<title>마이페이지 | 여기서놀자</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
/* ⚠️ CSS 원본 그대로 유지 */
* { box-sizing: border-box; }
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: url("background.jpg") no-repeat center center fixed;
    background-size: cover;
}
.topbar {
    background: rgba(0,0,0,0.75);
    padding: 15px 30px;
    color: #fff;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.logo { font-size: 24px; font-weight: bold; cursor: pointer; }
.logout { cursor: pointer; font-size: 15px; }

.main {
    max-width: 900px;
    margin: 40px auto;
    background: rgba(255,255,255,0.95);
    padding: 40px;
    border-radius: 14px;
}

.profile { text-align: center; }
.profile-img-wrap { position: relative; display: inline-block; }
.profile-img {
    width: 140px;
    height: 140px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #ddd;
}
.edit-icon {
    position: absolute;
    top: 5px;
    right: 5px;
    background: #000;
    color: #fff;
    border-radius: 50%;
    padding: 6px;
    font-size: 12px;
    cursor: pointer;
}
.nickname {
    margin-top: 15px;
    font-size: 20px;
    font-weight: bold;
}
.nickname span { margin-left: 8px; cursor: pointer; }

.section { margin-top: 40px; }
.section-title {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 15px;
}

.list-item {
    padding: 14px;
    border: 1px solid #ddd;
    border-radius: 8px;
    margin-bottom: 10px;
    cursor: pointer;
}
.list-item:hover { background: #f5f5f5; }

.info-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid #eee;
}

.email-area {
    display: flex;
    align-items: center;
    gap: 80px;
}

.apply-box {
    border: 1px solid #ddd;
    border-radius: 10px;
    padding: 20px;
}
.apply-box textarea {
    width: 100%;
    height: 90px;
    resize: none;
    padding: 10px;
    margin-top: 10px;
}
.apply-box button {
    margin-top: 10px;
    padding: 10px 18px;
    cursor: pointer;
}
.notice { font-size: 13px; color: #777; margin-top: 8px; }
.pending { margin-top: 10px; color: #444; font-weight: bold; }

.withdraw {
    margin-top: 15px;
    color: red;
    cursor: pointer;
}

footer {
    background: rgba(0,0,0,0.85);
    padding: 30px;
    text-align: center;
    margin-top: 60px;
}
footer button {
    margin: 10px;
    padding: 12px 20px;
    font-size: 16px;
    cursor: pointer;
}
</style>
</head>

<body>

<!-- 상단 -->
<div class="topbar">
    <div class="logo" onclick="goHome()">여기서놀자</div>
    <div class="logout" onclick="logout()">로그아웃</div>
</div>

<div class="main">

<!-- 프로필 -->
<div class="profile">
    <div class="profile-img-wrap">
        <img src="profile.jpg" id="profileImg" class="profile-img">
        <div class="edit-icon" onclick="changeProfile()">✏️</div>
    </div>

    <div class="nickname">
        <span id="nickname"><%= snick %></span>
        <span onclick="changeNickname()">✏️</span>
    </div>
</div>

<!-- 기록 -->
<div class="section">
    <div class="section-title">기록</div>
    <div class="list-item">❤️ 내가 좋아요 한 곳</div>
    <div class="list-item">✍️ 내가 작성한 글 확인</div>
</div>

<!-- 내정보 -->
<div class="section">
    <div class="section-title">내정보</div>

    <div class="info-row">
        <div>이름</div>
        <div><%= sname %></div>
    </div>

    <div class="info-row">
        <div>이메일</div>
        <div class="email-area">
            <span id="email"><%= semail %></span>
            <button onclick="changeEmail()">수정</button>
        </div>
    </div>

    <div class="withdraw" onclick="withdrawStep1()">회원 탈퇴</div>
</div>

<!-- 기자 등급 신청 -->
<div class="section">
    <div class="section-title">회원 → 기자 등급 변경 신청</div>

    <div class="apply-box">
        <div class="notice">
            ※ 가입 이후 7일이 경과되어야 신청이 가능합니다.
        </div>

        <% if ("WAIT".equals(reporter)) { %>
            <div class="pending">
                신청이 접수되었습니다.<br>
                3~5일 정도 소요됩니다.<br>
                기자 등급 심사중...
            </div>
        <% } else if ("N".equals(reporter)) { %>

            <textarea id="reason" placeholder="변경 신청 사유를 입력해주세요.
ex) 아름다운 여행지를 추천하고 싶습니다. 세상의 맛집을 소개합니다."></textarea>

            <button onclick="applyReporter()">신청</button>
            <div id="result" class="pending"></div>

        <% } else if ("Y".equals(reporter)) { %>
            <div class="pending">이미 기자 회원입니다.</div>
        <% } %>
    </div>
</div>

</div>

<footer>
    <button>저작권</button>
    <button>개인정보처리방침</button>
    <button>이용약관</button>
    <button>문의</button>
</footer>

<input type="file" id="fileInput" accept="image/*" style="display:none">

<script>
function goHome() { location.href = "index.jsp"; }
function logout() {
    alert("로그아웃 되었습니다.");
    location.href = "logout.jsp";
}
function changeProfile() {
    document.getElementById("fileInput").click();
}
function changeNickname() {
    const name = prompt("변경할 닉네임 입력");
    if(name) document.getElementById("nickname").innerText = name;
}
function changeEmail() {
    const email = prompt("변경할 이메일 입력");
    if(email) document.getElementById("email").innerText = email;
}
function withdrawStep1() {
    if(confirm("탈퇴 시 게시글 및 댓글은 유지되며 복구 불가합니다.\n그래도 탈퇴하시겠습니까?")) {
        alert("탈퇴 완료");
    }
}
function applyReporter() {
    document.getElementById("result").innerText =
        "신청이 접수되었습니다.\n3~5일 정도 소요됩니다.\n기자 등급 심사중...";
}
</script>

</body>
</html>
