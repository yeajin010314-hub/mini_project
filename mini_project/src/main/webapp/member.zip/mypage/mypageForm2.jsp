<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="web.member.MemberDTO" %>

<%
System.out.println("=== mypage 진입 ===");
System.out.println("URI = " + request.getRequestURI());
System.out.println("session id = " + session.getId());
%>

<div style="text-align:right; margin-bottom:20px;">
	<form action="<%=request.getContextPath()%>/member/logout"
	method="get">
	<button type="submit">로그아웃</button>
	</form>
	</div>
<%
    MemberDTO user =
      (MemberDTO)session.getAttribute("loginUser");

    if(user == null){
    	session.setAttribute("redirectAfterLogin",request.getRequestURI());
    	
    	
        response.sendRedirect("/mini_project/login/loginForm2.jsp");
        return;
    }
    
    
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>마이페이지</title>
</head>
<body>

<h2>마이페이지</h2>

<form action="/mini_project/member/update" method="post"
      onsubmit="return checkNickOk();">

    <p>아이디: <%= user.getMemberId() %></p>
    <p>이름: <%= user.getMemberNm() %></p>

    <p>
        닉네임:
        <input type="text" id="nick" name="nickNm"
               value="<%= user.getNickNm() %>">
        <button type="button" onclick="checkNick()">중복확인</button>
    </p>
    <div id="nickMsg"></div>

    <button type="submit">정보 수정</button>
</form>

<script>
let nickChecked = false;

function checkNick(){
    const nick = document.getElementById("nick").value.trim();
    const msg = document.getElementById("nickMsg");

    fetch("/mini_project/member/check", {
        method: "POST",
        headers: {"Content-Type":"application/x-www-form-urlencoded"},
        body: "type=nickNm&value=" + encodeURIComponent(nick)
    })
    .then(res => res.text())
    .then(data => {
        if(data.trim() === "DUP"){
            msg.innerText = "이미 사용 중인 닉네임";
            msg.style.color = "red";
            nickChecked = false;
        } else {
            msg.innerText = "사용 가능한 닉네임";
            msg.style.color = "green";
            nickChecked = true;
        }
    });
}

function checkNickOk(){
    if(!nickChecked){
        alert("닉네임 중복확인을 해주세요.");
        return false;
    }
    return true;
}


</script>

</body>
</html>
